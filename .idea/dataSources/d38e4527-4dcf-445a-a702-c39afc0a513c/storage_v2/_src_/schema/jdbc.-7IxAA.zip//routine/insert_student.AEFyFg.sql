create
    definer = root@localhost procedure insert_student(IN name_in varchar(100), IN age_in int)
begin
    insert into student(name, age)  value (name_in,age_in);
end;

